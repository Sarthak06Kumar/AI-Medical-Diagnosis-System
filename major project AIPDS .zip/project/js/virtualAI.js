// Virtual AI Assistant JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const virtualAiButton = document.getElementById('virtualAiButton');
    const virtualAiChat = document.getElementById('virtualAiChat');
    const closeVirtualAi = document.getElementById('closeVirtualAi');
    const virtualAiBody = document.getElementById('virtualAiBody');
    const virtualAiInput = document.getElementById('virtualAiInput');
    const sendVirtualAi = document.getElementById('sendVirtualAi');
    
    // Open chat
    virtualAiButton.addEventListener('click', () => {
        virtualAiChat.style.display = 'flex';
        virtualAiButton.style.display = 'none';
        virtualAiInput.focus();
    });
    
    // Close chat
    closeVirtualAi.addEventListener('click', () => {
        virtualAiChat.style.display = 'none';
        virtualAiButton.style.display = 'flex';
    });
    
    // Send message
    function sendMessage() {
        const message = virtualAiInput.value.trim();
        if (message === '') return;
        
        // Add user message
        addUserMessage(message);
        
        // Clear input
        virtualAiInput.value = '';
        
        // Get AI response
        getAiResponse(message);
    }
    
    // Send button
    sendVirtualAi.addEventListener('click', sendMessage);
    
    // Enter key
    virtualAiInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // Add user message to chat
    function addUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'user-message';
        messageElement.innerHTML = `
            <div class="user-bubble">${message}</div>
        `;
        virtualAiBody.appendChild(messageElement);
        
        // Scroll to bottom
        virtualAiBody.scrollTop = virtualAiBody.scrollHeight;
    }
    
    // Add AI message to chat
    function addAiMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'ai-message';
        messageElement.innerHTML = `
            <div class="ai-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="ai-bubble">${message}</div>
        `;
        virtualAiBody.appendChild(messageElement);
        
        // Scroll to bottom
        virtualAiBody.scrollTop = virtualAiBody.scrollHeight;
    }
    
    // Get AI response (simulated)
    function getAiResponse(userMessage) {
        // Show typing indicator
        const typingElement = document.createElement('div');
        typingElement.className = 'ai-message';
        typingElement.innerHTML = `
            <div class="ai-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="ai-bubble">
                <div class="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        virtualAiBody.appendChild(typingElement);
        
        // Scroll to bottom
        virtualAiBody.scrollTop = virtualAiBody.scrollHeight;
        
        // Simulate AI thinking
        setTimeout(() => {
            // Remove typing indicator
            virtualAiBody.removeChild(typingElement);
            
            // Get appropriate response
            const response = getResponseForMessage(userMessage);
            
            // Add AI response
            addAiMessage(response);
        }, 1500);
    }
    
    // Get appropriate response for user message
    function getResponseForMessage(message) {
        message = message.toLowerCase();
        
        if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
            return 'Hello! How can I help you with your medical diagnosis today?';
        } else if (message.includes('help') || message.includes('how to')) {
            return 'To use the classification tool, first select a diagnosis category, then upload your medical image by dragging and dropping or browsing for the file. Once uploaded, click the "Analyze Image" button to get your results.';
        } else if (message.includes('upload') || message.includes('file')) {
            return 'You can upload JPG, PNG, or PDF files up to 20MB in size. Simply drag and drop your file onto the upload area or click to browse your files.';
        } else if (message.includes('result') || message.includes('diagnosis')) {
            return 'Once your image is analyzed, you\'ll receive a detailed report including findings, visualizations with areas of interest highlighted, and confidence scores for different conditions.';
        } else if (message.includes('thank')) {
            return 'You\'re welcome! Is there anything else I can help you with?';
        } else if (message.includes('contact') || message.includes('support')) {
            return 'For additional support, you can contact our team at support@mediscan.ai or call (555) 123-4567 during business hours.';
        } else if (message.includes('category') || message.includes('condition')) {
            return 'We offer analysis for multiple categories including Chest & Lung, Brain & Neurological, Abdominal & Organ, Bone & Joint, Cardiac & Vascular, and other conditions. Choose the one that best matches your needs.';
        } else if (message.includes('accurate') || message.includes('accuracy')) {
            return 'Our AI has been trained on thousands of medical images and achieves high accuracy rates, but results should always be reviewed by a medical professional. The tool is designed to assist, not replace, professional medical diagnosis.';
        } else {
            return 'I\'m here to help with the MediScan tool. You can ask me about how to upload images, interpret results, or any other questions about using our AI diagnosis system.';
        }
    }
});
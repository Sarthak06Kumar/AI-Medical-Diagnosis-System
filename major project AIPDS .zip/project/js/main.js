// Main JavaScript functionality

// Handle scroll animations
document.addEventListener('DOMContentLoaded', function() {
    // Animate elements on scroll
    const animateElements = document.querySelectorAll('.feature-card, .team-member');
    
    function checkIfInView() {
        animateElements.forEach((element, index) => {
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementTop < window.innerHeight - elementVisible) {
                element.classList.add('show');
                element.style.animationDelay = `${index * 0.1}s`;
            }
        });
    }

    // Initial check on page load
    checkIfInView();
    
    // Check on scroll
    window.addEventListener('scroll', checkIfInView);

    // Handle smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Create placeholder images if they don't exist
    createPlaceholderImages();
});

// Function to create placeholder images for demo purposes
function createPlaceholderImages() {
    // Create logo placeholders
    const logoPlaceholder = document.createElement('img');
    logoPlaceholder.src = 'https://placehold.co/200x200/0078d7/FFFFFF?text=MediScan';
    
    const logoWhitePlaceholder = document.createElement('img');
    logoWhitePlaceholder.src = 'https://placehold.co/200x200/0078d7/FFFFFF?text=MediScan';
    
    // Create hero image placeholder
    const heroImagePlaceholder = document.createElement('img');
    heroImagePlaceholder.src = 'https://images.pexels.com/photos/3825368/pexels-photo-3825368.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1';
    
    // Store in localStorage to simulate file existence
    localStorage.setItem('logo', logoPlaceholder.src);
    localStorage.setItem('logo-white', logoWhitePlaceholder.src);
    localStorage.setItem('hero-image', heroImagePlaceholder.src);
    
    // Update src attributes
    document.querySelectorAll('img[src="assets/logo.png"]').forEach(img => {
        img.src = logoPlaceholder.src;
    });
    
    document.querySelectorAll('img[src="assets/logo-white.png"]').forEach(img => {
        img.src = logoWhitePlaceholder.src;
    });
    
    document.querySelectorAll('img[src="assets/hero-image.png"]').forEach(img => {
        img.src = heroImagePlaceholder.src;
    });
}
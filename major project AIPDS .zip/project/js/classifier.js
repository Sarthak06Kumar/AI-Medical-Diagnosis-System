// Classification Tool JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const uploadArea = document.getElementById('uploadArea');
    const fileUpload = document.getElementById('fileUpload');
    const previewArea = document.getElementById('previewArea');
    const previewImage = document.getElementById('previewImage');
    const fileInfo = document.getElementById('fileInfo');
    const removeFile = document.getElementById('removeFile');
    const analyzeButton = document.getElementById('analyzeButton');
    const resultsSection = document.getElementById('resultsSection');
    const resultImage = document.getElementById('resultImage');
    const annotatedImage = document.getElementById('annotatedImage');
    const diagnosisSummary = document.getElementById('diagnosisSummary');
    const newAnalysisBtn = document.getElementById('newAnalysisBtn');
    const downloadReportBtn = document.getElementById('downloadReportBtn');
    const shareResultsBtn = document.getElementById('shareResultsBtn');
    const specificCondition = document.getElementById('specificCondition');
    const diagnosisCategories = document.getElementById('diagnosisCategories');
    
    // Variables
    let uploadedFile = null;
    
    // Update condition options based on category selection
    function updateConditionOptions() {
        const selectedCategory = document.querySelector('input[name="diagnosisCategory"]:checked').value;
        specificCondition.innerHTML = '<option selected disabled>Select condition</option>';
        
        let options = [];
        
        switch(selectedCategory) {
            case 'chest':
                options = [
                    { value: 'pneumonia', text: 'Pneumonia' },
                    { value: 'tuberculosis', text: 'Tuberculosis' },
                    { value: 'covid19', text: 'COVID-19' },
                    { value: 'lung_cancer', text: 'Lung Cancer' },
                    { value: 'pleural_effusion', text: 'Pleural Effusion' }
                ];
                break;
            case 'brain':
                options = [
                    { value: 'brain_tumor', text: 'Brain Tumor' },
                    { value: 'stroke', text: 'Stroke' },
                    { value: 'alzheimers', text: 'Alzheimer\'s Disease' },
                    { value: 'multiple_sclerosis', text: 'Multiple Sclerosis' }
                ];
                break;
            case 'abdomen':
                options = [
                    { value: 'liver_cirrhosis', text: 'Liver Cirrhosis' },
                    { value: 'kidney_stones', text: 'Kidney Stones' },
                    { value: 'appendicitis', text: 'Appendicitis' },
                    { value: 'gallstones', text: 'Gallstones' }
                ];
                break;
            case 'bone':
                options = [
                    { value: 'fracture', text: 'Fracture' },
                    { value: 'osteoporosis', text: 'Osteoporosis' },
                    { value: 'arthritis', text: 'Arthritis' },
                    { value: 'bone_cancer', text: 'Bone Cancer' }
                ];
                break;
            case 'cardiac':
                options = [
                    { value: 'coronary_artery_disease', text: 'Coronary Artery Disease' },
                    { value: 'heart_failure', text: 'Heart Failure' },
                    { value: 'valve_disease', text: 'Valve Disease' },
                    { value: 'arrhythmia', text: 'Arrhythmia' }
                ];
                break;
            case 'other':
                options = [
                    { value: 'diabetes', text: 'Diabetes' },
                    { value: 'thyroid', text: 'Thyroid Disorders' },
                    { value: 'skin_conditions', text: 'Skin Conditions' }
                ];
                break;
        }
        
        // Add options to select
        options.forEach(option => {
            const optionElement = document.createElement('option');
            optionElement.value = option.value;
            optionElement.textContent = option.text;
            specificCondition.appendChild(optionElement);
        });
    }
    
    // Initialize condition options
    updateConditionOptions();
    
    // Listen for category changes
    document.querySelectorAll('input[name="diagnosisCategory"]').forEach(radio => {
        radio.addEventListener('change', updateConditionOptions);
    });
    
    // Upload area drag and drop events
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        if (e.dataTransfer.files.length) {
            handleFileUpload(e.dataTransfer.files[0]);
        }
    });
    
    // Click on upload area
    uploadArea.addEventListener('click', () => {
        fileUpload.click();
    });
    
    // File input change
    fileUpload.addEventListener('change', (e) => {
        if (e.target.files.length) {
            handleFileUpload(e.target.files[0]);
        }
    });
    
    // Remove file button
    removeFile.addEventListener('click', () => {
        resetUpload();
    });
    
    // Analyze button
    analyzeButton.addEventListener('click', () => {
        if (uploadedFile) {
            showAnalysisResults();
        }
    });
    
    // New analysis button
    newAnalysisBtn.addEventListener('click', () => {
        resetUpload();
        resultsSection.classList.add('d-none');
    });
    
    // Download report button
    downloadReportBtn.addEventListener('click', () => {
        // Simulate report download
        alert('Report download started...');
        setTimeout(() => {
            alert('Report downloaded successfully!');
        }, 1500);
    });
    
    // Share results button
    shareResultsBtn.addEventListener('click', () => {
        if (navigator.share) {
            navigator.share({
                title: 'MediScan Analysis Results',
                text: 'Check out my medical scan analysis from MediScan!',
                url: window.location.href
            })
            .then(() => console.log('Share successful'))
            .catch(error => console.log('Error sharing:', error));
        } else {
            // Fallback
            const dummyInput = document.createElement('input');
            dummyInput.value = window.location.href;
            document.body.appendChild(dummyInput);
            dummyInput.select();
            document.execCommand('copy');
            document.body.removeChild(dummyInput);
            
            alert('Link copied to clipboard!');
        }
    });
    
    // Handle file upload
    function handleFileUpload(file) {
        // Check file type
        const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
        if (!validTypes.includes(file.type)) {
            alert('Please upload a valid file (JPG, PNG, or PDF)');
            return;
        }
        
        // Check file size (max 20MB)
        if (file.size > 20 * 1024 * 1024) {
            alert('File size exceeds 20MB limit');
            return;
        }
        
        uploadedFile = file;
        
        // Show preview
        if (file.type !== 'application/pdf') {
            const reader = new FileReader();
            reader.onload = (e) => {
                previewImage.src = e.target.result;
                previewArea.classList.remove('d-none');
                uploadArea.classList.add('d-none');
                
                // Format file size
                const fileSize = formatFileSize(file.size);
                fileInfo.textContent = `${file.name} (${fileSize})`;
                
                // Enable analyze button
                analyzeButton.disabled = false;
            };
            reader.readAsDataURL(file);
        } else {
            // For PDF files
            previewImage.src = 'https://placehold.co/600x400/e9ecef/495057?text=PDF+Preview';
            previewArea.classList.remove('d-none');
            uploadArea.classList.add('d-none');
            
            // Format file size
            const fileSize = formatFileSize(file.size);
            fileInfo.textContent = `${file.name} (${fileSize})`;
            
            // Enable analyze button
            analyzeButton.disabled = false;
        }
    }
    
    // Reset upload
    function resetUpload() {
        uploadedFile = null;
        fileUpload.value = '';
        previewArea.classList.add('d-none');
        uploadArea.classList.remove('d-none');
        analyzeButton.disabled = true;
    }
    
    // Format file size
    function formatFileSize(bytes) {
        if (bytes < 1024) {
            return bytes + ' bytes';
        } else if (bytes < 1024 * 1024) {
            return (bytes / 1024).toFixed(2) + ' KB';
        } else {
            return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
        }
    }
    
    // Show analysis results
    function showAnalysisResults() {
        // Show loading state
        analyzeButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Analyzing...';
        analyzeButton.disabled = true;
        
        // Simulate AI processing
        setTimeout(() => {
            // Reset button
            analyzeButton.innerHTML = '<i class="fas fa-microscope me-2"></i> Analyze Image';
            analyzeButton.disabled = false;
            
            // Show results section
            resultsSection.classList.remove('d-none');
            
            // Smooth scroll to results
            resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            
            // Set result images
            resultImage.src = previewImage.src;
            
            // Set annotated image (would be generated by AI in real app)
            // For demo, use a placeholder with overlay
            if (uploadedFile.type !== 'application/pdf') {
                createAnnotatedImage();
            } else {
                annotatedImage.src = 'https://placehold.co/600x400/e9ecef/495057?text=PDF+Analysis';
            }
            
            // Set diagnosis summary based on selected condition
            updateDiagnosisSummary();
            
            // Animate findings
            const findingItems = document.querySelectorAll('.finding-item');
            findingItems.forEach((item, index) => {
                item.style.setProperty('--i', index);
            });
        }, 2000);
    }
    
    // Create annotated image with overlays (simulated for demo)
    function createAnnotatedImage() {
        // In a real app, this would be generated by the AI
        // For demo, we'll just use the same image with a colored overlay
        const canvas = document.createElement('canvas');
        const img = new Image();
        
        img.onload = function() {
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            
            // Draw original image
            ctx.drawImage(img, 0, 0);
            
            // Add simulated annotation overlays
            ctx.fillStyle = 'rgba(255, 0, 0, 0.3)';
            ctx.beginPath();
            ctx.ellipse(img.width * 0.6, img.height * 0.4, img.width * 0.2, img.height * 0.2, 0, 0, 2 * Math.PI);
            ctx.fill();
            
            // Add text annotation
            ctx.fillStyle = 'white';
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 2;
            ctx.font = 'bold 16px Arial';
            ctx.textAlign = 'center';
            ctx.strokeText('Abnormality', img.width * 0.6, img.height * 0.4);
            ctx.fillText('Abnormality', img.width * 0.6, img.height * 0.4);
            
            // Set annotated image
            annotatedImage.src = canvas.toDataURL('image/png');
        };
        
        img.src = previewImage.src;
    }
    
    // Update diagnosis summary based on selected condition
    function updateDiagnosisSummary() {
        const selectedCategory = document.querySelector('input[name="diagnosisCategory"]:checked').value;
        const selectedCondition = specificCondition.value;
        
        let summaryText = '';
        
        if (selectedCondition === 'pneumonia') {
            summaryText = '<i class="fas fa-info-circle me-2"></i> Based on the analysis, there is a high probability of pneumonia detected in the right lung.';
        } else if (selectedCondition === 'brain_tumor') {
            summaryText = '<i class="fas fa-info-circle me-2"></i> Based on the analysis, there is evidence of a mass in the right frontal lobe that may be consistent with a tumor.';
        } else if (selectedCondition === 'fracture') {
            summaryText = '<i class="fas fa-info-circle me-2"></i> Based on the analysis, there appears to be a transverse fracture in the distal radius.';
        } else {
            summaryText = '<i class="fas fa-info-circle me-2"></i> Based on the analysis, several findings have been identified. Please review the detailed report below.';
        }
        
        diagnosisSummary.innerHTML = summaryText;
    }
});